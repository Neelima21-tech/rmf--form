/*global QUnit*/

sap.ui.define([
	"com/wl/qm/zrmaform/controller/RMA_Form.controller"
], function (Controller) {
	"use strict";

	QUnit.module("RMA_Form Controller");

	QUnit.test("I should test the RMA_Form controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});
