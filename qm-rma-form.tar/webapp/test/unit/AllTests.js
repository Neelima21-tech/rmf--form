sap.ui.define([
	"com/wl/qm/zrmaform/test/unit/controller/RMA_Form.controller"
], function () {
	"use strict";
});
