sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageBox",
    "sap/m/MessageToast",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator"
], (Controller, JSONModel, MessageBox, MessageToast, Filter, FilterOperator) => {
    "use strict";


    return Controller.extend("com.wl.qm.zrmaform.controller.RMA_Form", {
        // Initialization function, called when the controller is instantiated
        onInit: function () {

        },
        // Function to retrieve localized text from i18n model
        changei18n: function (sText, sPlaceholder) {
            var oResourceBundle = this.getOwnerComponent().getModel("i18n");
            var cText = oResourceBundle.getResourceBundle().getText(sText, sPlaceholder);
            return cText;
        },

        // Event handler for button press
        onBtnPress: function (oEvent) {
            var sButtonText = oEvent.getSource().getProperty("text");
            var oView = this.getView();
            var oEntity;
            var oModel = oView.getModel("rmaModel");
            var aFilter = [];

            // Check if RMA number field is filled; if not, show message and exit
            if (oView.byId("RmaNumber").getValue()) {
                aFilter.push(new Filter({
                    path: "RMA_NUM",
                    operator: FilterOperator.EQ,
                    value1: oView.byId("RmaNumber").getValue()
                }));
            }
            else {

                sap.m.MessageToast.show(this.changei18n("pleaseFillRma"));



                return;
            }
            if (oView.byId("IssueDate").getValue()) {
                aFilter.push(new Filter({
                    path: "ISSUE_DATE",
                    operator: FilterOperator.EQ,
                    value1: oView.byId("IssueDate").getValue() != "" ? this.formatDate(oView.byId("IssueDate").getValue()) : ""
                }));

            }
            if (oView.byId("IssueBy").getValue()) {
                aFilter.push(new Filter({
                    path: "ISSUE_BY",
                    operator: FilterOperator.EQ,
                    value1: oView.byId("IssueBy").getValue()
                }));

            }
            if (oView.byId("Customer").getValue()) {
                aFilter.push(new Filter({
                    path: "CUSTOMER",
                    operator: FilterOperator.EQ,
                    value1: oView.byId("Customer").getValue()
                }));

            }
            if (oView.byId("CustomerContact").getValue()) {
                aFilter.push(new Filter({
                    path: "CUST_CONTACT",
                    operator: FilterOperator.EQ,
                    value1: oView.byId("CustomerContact").getValue()
                }));

            }
            if (oView.byId("WemPartNumber").getValue()) {
                aFilter.push(new Filter({
                    path: "WCM_PART",
                    operator: FilterOperator.EQ,
                    value1: oView.byId("WemPartNumber").getValue()
                }));

            }
            if (oView.byId("CustomerPartNumber").getValue()) {
                aFilter.push(new Filter({
                    path: "CUST_PART",
                    operator: FilterOperator.EQ,
                    value1: oView.byId("CustomerPartNumber").getValue()
                }));

            }
            if (oView.byId("LotNumber").getValue()) {
                aFilter.push(new Filter({
                    path: "LOT_NUM",
                    operator: FilterOperator.EQ,
                    value1: oView.byId("LotNumber").getValue()
                }));

            }
            if (oView.byId("QTY").getValue()) {
                aFilter.push(new Filter({
                    path: "QTY",
                    operator: FilterOperator.EQ,
                    value1: oView.byId("QTY").getValue() != "" ? oView.byId("QTY").getValue() : "0"

                }));

            }
            if (oView.byId("InvoiceNumber").getValue()) {
                aFilter.push(new Filter({
                    path: "INVOICE",
                    operator: FilterOperator.EQ,
                    value1: oView.byId("InvoiceNumber").getValue()
                }));

            }
            if (oView.byId("UnitPrice").getValue()) {
                aFilter.push(new Filter({
                    path: "UNIT_PRICE",
                    operator: FilterOperator.EQ,
                    value1: oView.byId("UnitPrice").getValue() != "" ? oView.byId("UnitPrice").getValue() : "0"
                }));

            }
            if (oView.byId("CreditAmount").getValue()) {
                aFilter.push(new Filter({
                    path: "CREDIT_AMT",
                    operator: FilterOperator.EQ,
                    value1: oView.byId("CreditAmount").getValue() != "" ? oView.byId("CreditAmount").getValue() : "0"
                }));

            }
            if (oView.byId("PO").getValue()) {
                aFilter.push(new Filter({
                    path: "PO",
                    operator: FilterOperator.EQ,
                    value1: oView.byId("PO").getValue()
                }));

            }
            if (oView.byId("CauseDescription").getValue()) {
                aFilter.push(new Filter({
                    path: "CAUSE",
                    operator: FilterOperator.EQ,
                    value1: oView.byId("CauseDescription").getValue()
                }));

            }
            if (oView.byId("CorrectiveAction").getValue()) {
                aFilter.push(new Filter({
                    path: "CORRECTIVE_ACT",
                    operator: FilterOperator.EQ,
                    value1: oView.byId("CorrectiveAction").getValue()
                }));

            }
            if (oView.byId("QuantityReceived").getValue()) {
                aFilter.push(new Filter({
                    path: "QTY_RECEIVED",
                    operator: FilterOperator.EQ,
                    value1: oView.byId("QuantityReceived").getValue()
                }));

            }
            if (oView.byId("DateReceived").getValue()) {
                aFilter.push(new Filter({
                    path: "DATE_RECEIVED",
                    operator: FilterOperator.EQ,
                    value1: oView.byId("DateReceived").getValue() != "" ? this.formatDate(oView.byId("DateReceived").getValue()) : "",
                }));

            }
            if (oView.byId("Code").getValue()) {
                aFilter.push(new Filter({
                    path: "CODE",
                    operator: FilterOperator.EQ,
                    value1: oView.byId("Code").getValue() != "" ? oView.byId("Code").getValue() : "0"
                }));

            }
            if (oView.byId("EngineerResponsible").getValue()) {
                aFilter.push(new Filter({
                    path: "ENGINEER_RESP",
                    operator: FilterOperator.EQ,
                    value1: oView.byId("EngineerResponsible").getValue()
                }));

            }
            if (oView.byId("NexCar").getValue()) {
                aFilter.push(new Filter({
                    path: "CAR_8D",
                    operator: FilterOperator.EQ,
                    value1: oView.byId("NexCar").getValue()
                }));

            }
            if (oView.byId("MaterialStored").getValue()) {
                aFilter.push(new Filter({
                    path: "MATERIAL_STORED",
                    operator: FilterOperator.EQ,
                    value1: oView.byId("MaterialStored").getValue()
                }));
            }
            if (oView.byId("Email").getValue()) {
                aFilter.push(new Filter({
                    path: "EMAIL_ID",
                    operator: FilterOperator.EQ,
                    value1: oView.byId("Email").getValue()
                }));
            }
            // Set specific actions based on button text
            if (sButtonText === this.changei18n("reviewForm")) {
                aFilter.push(new Filter({
                    path: "REVIEW_FORM",
                    operator: FilterOperator.EQ,
                    value1: "X"
                }));
            }
            else if (sButtonText === this.changei18n("emailSaveForm")) {
                aFilter.push(new Filter({
                    path: "SAVE_DATA",
                    operator: FilterOperator.EQ,
                    value1: "X"
                }));
            }
            else {
                aFilter.push(new Filter({
                    path: "RETRIEVE",
                    operator: FilterOperator.EQ,
                    value1: "X"
                }));
            }


            // Perform data retrieval from SAP model
            var oModel = this.getOwnerComponent().getModel();
            oModel.read("/ZQM_CDS_I_RMA",
                {

                    filters: aFilter,
                    success: function (oResponse) {
                        if (sButtonText === this.changei18n("reviewForm")) {
                            this._convertBase64ToPDF(oResponse.results[0].FORMDATA);
                        }
                        else if (sButtonText === this.changei18n("emailSaveForm")) {
                            MessageToast.show(this.changei18n("rmasub"));
                            // this._convertBase64ToPDF(oResponse.results[0].FORMDATA);

                        }
                        else {
                            if (oResponse.results.length > 0) {


                                this.successRetrive(oResponse);
                            }
                            else {
                                MessageToast.show(this.changei18n("noData"));
                            }
                        }


                        sap.ui.core.BusyIndicator.hide();
                    }.bind(this),
                    error: function (oError) {
                        sap.ui.core.BusyIndicator.hide();

                        MessageBox.error("error");
                    }.bind(this)
                });
        },
        // Function to convert Base64 string to PDF and open it
        _convertBase64ToPDF: function (base64String) {

            const byteCharacters = atob(base64String);    //to decode
            const byteNumbers = new Array(byteCharacters.length);  // array of 8 bitd
            for (let i = 0; i < byteCharacters.length; i++) {
                byteNumbers[i] = byteCharacters.charCodeAt(i);
            }
            const byteArray = new Uint8Array(byteNumbers);
            const blob = new Blob([byteArray], { type: 'application/pdf' }); //unknown blob

            const blobUrl = URL.createObjectURL(blob);
            window.open(blobUrl);  // proview in window as print
            //:- download bgn
            const link = document.createElement('a');
            link.href = blobUrl;
            link.download = 'form_pdf.pdf';
            link.click();
            //:- download end
        },


        // Function to format date before sending to backend
        formatDate: function (oDate) {
            if (!oDate) {
                return oDate;
            }
            else {
                "MM/dd/YYYY"
                var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
                    UTC: true,
                    pattern: "yyyy-MM-dd\'T\'HH:mm:ss"

                });
                var formattedDate = oDateFormat.format(new Date(oDate.split("/")[2], oDate.split("/")[1], oDate.split("/")[0]));
                return formattedDate;
            }
        },
        // Function to format retrieved date for UI display
        formatDateRet: function (oDate) {
            if (!oDate) {
                return oDate;
            }
            else {
                var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
                    UTC: true,
                    pattern: "MM/dd/yyyy"

                });
                var formattedDate = oDateFormat.format(new Date(oDate));
                return formattedDate;
            }
        },
        // Function to populate form fields with retrieved data
        successRetrive: function (oData) {

            this.getView().byId("RmaNumber").setValue(oData.results[0].RMA_NUM);
            this.getView().byId("IssueDate").setValue(this.formatDateRet(oData.results[0].ISSUE_DATE));
            this.getView().byId("IssueBy").setValue(oData.results[0].ISSUE_BY);
            this.getView().byId("Customer").setValue(oData.results[0].CUSTOMER);
            this.getView().byId("CustomerContact").setValue(oData.results[0].CUST_CONTACT);
            this.getView().byId("WemPartNumber").setValue(oData.results[0].WCM_PART);
            this.getView().byId("CustomerPartNumber").setValue(oData.results[0].CUST_PART);
            this.getView().byId("LotNumber").setValue(oData.results[0].LOT_NUM);
            this.getView().byId("QTY").setValue(oData.results[0].QTY);
            this.getView().byId("InvoiceNumber").setValue(oData.results[0].INVOICE);
            this.getView().byId("UnitPrice").setValue(oData.results[0].UNIT_PRICE);
            this.getView().byId("CreditAmount").setValue(oData.results[0].CREDIT_AMT);
            this.getView().byId("PO").setValue(oData.results[0].PO);
            this.getView().byId("CauseDescription").setValue(oData.results[0].CAUSE);
            this.getView().byId("CorrectiveAction").setValue(oData.results[0].CORRECTIVE_ACT);
            this.getView().byId("QuantityReceived").setValue(oData.results[0].QTY_RECEIVED);
            this.getView().byId("DateReceived").setValue(this.formatDateRet(oData.results[0].DATE_RECEIVED));
            this.getView().byId("Code").setValue(oData.results[0].CODE);
            this.getView().byId("EngineerResponsible").setValue(oData.results[0].ENGINEER_RESP);
            this.getView().byId("NexCar").setValue(oData.results[0].CAR_8D);
            this.getView().byId("MaterialStored").setValue(oData.results[0].MATERIAL_STORED);
            this.getView().byId("Email").setValue(oData.results[0].EMAIL_ID);
        }
    });
});